/********************************************************************************
** Form generated from reading UI file 'delfriwin.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DELFRIWIN_H
#define UI_DELFRIWIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DelFriWin
{
public:
    QLabel *label;
    QLineEdit *lineEdit;
    QPushButton *pushButton;

    void setupUi(QWidget *DelFriWin)
    {
        if (DelFriWin->objectName().isEmpty())
            DelFriWin->setObjectName(QStringLiteral("DelFriWin"));
        DelFriWin->resize(295, 181);
        DelFriWin->setStyleSheet(QStringLiteral("#DelFriWin{border-image: url(:/res/resource/background/backgroud8.jfif);}"));
        label = new QLabel(DelFriWin);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(51, 20, 191, 51));
        QFont font;
        font.setPointSize(10);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);
        lineEdit = new QLineEdit(DelFriWin);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(62, 69, 171, 20));
        pushButton = new QPushButton(DelFriWin);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(110, 124, 75, 23));

        retranslateUi(DelFriWin);

        QMetaObject::connectSlotsByName(DelFriWin);
    } // setupUi

    void retranslateUi(QWidget *DelFriWin)
    {
        DelFriWin->setWindowTitle(QApplication::translate("DelFriWin", "Form", Q_NULLPTR));
        label->setText(QApplication::translate("DelFriWin", "\350\257\267\350\276\223\345\205\245\344\275\240\346\203\263\345\210\240\351\231\244\345\245\275\345\217\213\347\232\204\347\224\250\346\210\267\345\220\215", Q_NULLPTR));
        pushButton->setText(QApplication::translate("DelFriWin", "\347\241\256\350\256\244", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class DelFriWin: public Ui_DelFriWin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DELFRIWIN_H
