#ifndef ADDFRIRES_H
#define ADDFRIRES_H

#include <QWidget>
#include <QTcpSocket>
#include <QDebug>
#include <QMessageBox>

namespace Ui {
class AddFriRes;
}

class AddFriRes : public QWidget
{
    Q_OBJECT

public:
    explicit AddFriRes(QWidget *parent = 0);
    explicit AddFriRes(QTcpSocket *sock, QString passuName, QString passfriuName, QString passTestMsg, QString passGroupMsg, QWidget *parent = 0);
    ~AddFriRes();

private slots:
    void on_agreeBtn_clicked();

    void on_rejectBtn_clicked();

private:
    Ui::AddFriRes *ui;
    QString uName;
    QString friuName;
    QString testMsg;
    QString groupMsg;
    QTcpSocket *client;
};

#endif // ADDFRIRES_H
