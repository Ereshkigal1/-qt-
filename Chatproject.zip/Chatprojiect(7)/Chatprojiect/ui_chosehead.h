/********************************************************************************
** Form generated from reading UI file 'chosehead.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHOSEHEAD_H
#define UI_CHOSEHEAD_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_ChoseHead
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_2;

    void setupUi(QDialog *ChoseHead)
    {
        if (ChoseHead->objectName().isEmpty())
            ChoseHead->setObjectName(QStringLiteral("ChoseHead"));
        ChoseHead->resize(469, 355);
        ChoseHead->setStyleSheet(QStringLiteral("#ChoseHead{border-image: url(:/res/resource/background/backgroud8.jfif);}"));
        pushButton = new QPushButton(ChoseHead);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setEnabled(false);
        pushButton->setGeometry(QRect(180, 280, 93, 41));
        QFont font;
        font.setFamily(QStringLiteral("AcadEref"));
        font.setPointSize(16);
        pushButton->setFont(font);
        pushButton_3 = new QPushButton(ChoseHead);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(200, 46, 71, 71));
        pushButton_3->setStyleSheet(QLatin1String("\n"
"border-image: url(:/res/resource/touxiang/1.bmp);"));
        pushButton_4 = new QPushButton(ChoseHead);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(331, 44, 71, 71));
        pushButton_4->setStyleSheet(QStringLiteral("border-image: url(:/res/resource/touxiang/2.bmp);"));
        pushButton_5 = new QPushButton(ChoseHead);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(71, 169, 71, 71));
        pushButton_5->setStyleSheet(QStringLiteral("border-image: url(:/res/resource/touxiang/3.bmp);"));
        pushButton_6 = new QPushButton(ChoseHead);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(201, 168, 71, 71));
        pushButton_6->setStyleSheet(QStringLiteral("border-image: url(:/res/resource/touxiang/4.bmp);"));
        pushButton_7 = new QPushButton(ChoseHead);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setEnabled(true);
        pushButton_7->setGeometry(QRect(331, 167, 71, 71));
        pushButton_7->setStyleSheet(QStringLiteral("border-image: url(:/res/resource/touxiang/5.bmp);"));
        pushButton_2 = new QPushButton(ChoseHead);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(72, 47, 71, 71));
        pushButton_2->setStyleSheet(QStringLiteral("border-image: url(:/res/resource/touxiang/0.bmp);"));

        retranslateUi(ChoseHead);

        QMetaObject::connectSlotsByName(ChoseHead);
    } // setupUi

    void retranslateUi(QDialog *ChoseHead)
    {
        ChoseHead->setWindowTitle(QApplication::translate("ChoseHead", "Dialog", Q_NULLPTR));
        pushButton->setText(QApplication::translate("ChoseHead", "\347\241\256\350\256\244", Q_NULLPTR));
        pushButton_3->setText(QString());
        pushButton_4->setText(QString());
        pushButton_5->setText(QString());
        pushButton_6->setText(QString());
        pushButton_7->setText(QString());
        pushButton_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class ChoseHead: public Ui_ChoseHead {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHOSEHEAD_H
