/*#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::MainWindow(QTcpSocket *sock, QString passuName, QString passfriuName, QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    client = sock;
    friuName = passfriuName;
    uName = passuName;
    connect(client, SIGNAL(readyRead()), this, SLOT(handReadyRead()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString msg = ui->lineEdit->text();
    QString packData = "#3|Amy|" + msg + '&';

    client->write(packData.toLocal8Bit());
}

void MainWindow::handReadyRead()
{
    QByteArray recvArray = client->readAll();
    if(recvArray.at(0) != '#' || recvArray.at(recvArray.size()-1) != '&')
        return;
    QString recvStr = QString::fromLocal8Bit(recvArray);
    recvStr = recvStr.mid(1, recvStr.length()-2);

    QStringList recvList = recvStr.split('|');
    if(recvList.size() < 3)
        return;
    if(recvList[0] == "3")
    {
        ui->textEdit->append(recvList[1] + ": " + recvList[2]);
    }
}
*/

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "qnchatmessage.h"
#include <QDateTime>
#include <QMessageBox>
#include <QUdpSocket>
#include <QHostInfo>
#include <QScrollBar>
#include <QNetworkInterface>
#include <QProcess>
#include <QFileDialog>
#include <QColorDialog>
#include <QPainter>
#include <QPixmap>
#include <QKeyEvent>
#include <QDialog>
#include <QHostAddress>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

//MainWindow::MainWindow(QTcpSocket *sock, QWidget *parent) :
//    QMainWindow(parent),
//    ui(new Ui::MainWindow)
//{
//    ui->setupUi(this);
//    resize(600, 800);
//    client = sock;
//    connect(client, SIGNAL(readyRead()), this, SLOT(handReadyRead()));
//}

MainWindow::MainWindow(QString passmyfriend, QString myfriendhead, QString passuName, QString myhead, QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    myfriendhead(myfriendhead),
    myhead(myhead)
{
    ui->setupUi(this);
    //connect(client, SIGNAL(readyRead()), this, SLOT(handReadyRead()));
    uName = passuName;
    myfriend = passmyfriend;
    qDebug()<<"uName"<<myhead;
    qDebug()<<"friuName"<<myfriendhead;
    ui->lineEdit_2->setText(myfriend);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{

    //QString msg = ui->lineEdit->text();

    //QDateTime dateTime= QDateTime::currentDateTime();//获取系统当前的时间
    //QString timeStr = dateTime .toString("MM-dd hh:mm \n");//格式化时间
    //ui->textEdit->append(timeStr + uName + ": " + msg);



    QString msg = ui->textEdit->toPlainText();
    if(msg == ""){
        QMessageBox::warning(this,"警告","无法发送空白消息");
        return;
    }
    ui->textEdit->setText("");
    QString time = QString::number(QDateTime::currentDateTime().toTime_t()); //时间戳
    QString packData = "#|3|" + uName + "|"+ myfriend + "|" + msg + "|&";
    //ui->lineEdit->setText("");
    //client->write(packData.toLocal8Bit());
    //client->write(packData.toUtf8());
    emit sendChatRecvMsgSig(packData);

    qDebug()<<"addMessage" << msg << time << ui->listWidget->count();

    dealMessageTime(time);

    QNChatMessage* messageW = new QNChatMessage(MainWindow::selectmyfriendhead(), MainWindow::selectmyhead(),ui->listWidget->parentWidget());
    QListWidgetItem* item = new QListWidgetItem(ui->listWidget);
    dealMessage(messageW, item, msg, time, QNChatMessage::User_Me);

    ui->listWidget->setCurrentRow(ui->listWidget->count()-1);
}

//void MainWindow::handReadyRead()
//{
//    QByteArray recvArray = client->readAll();
//    if(recvArray.at(0) != '#' || recvArray.at(recvArray.size()-1) != '&')
//        return;
//    //QString recvStr = QString::fromLocal8Bit(recvArray);
//    QString recvStr = QString::fromUtf8(recvArray);
//    recvStr = recvStr.mid(1, recvStr.length()-2);

//    QStringList recvList = recvStr.split('|');
//    if(recvList.size() < 3)
//        return;
//    if(recvList[0] == "3" && recvList[1] == "0")
//    {
//        //QDateTime dateTime= QDateTime::currentDateTime();//获取系统当前的时间
//        //QString timeStr = dateTime .toString("MM-dd hh:mm \n");//格式化时间
//        //ui->textEdit->append(timeStr + recvList[2] + ": " + recvList[4]);
//        if(recvList[4] != "") {
//            QString time = QString::number(QDateTime::currentDateTime().toTime_t()); //时间戳
//            dealMessageTime(time);

//            QNChatMessage* messageW = new QNChatMessage(MainWindow::selectmyfriendhead(),MainWindow::selectmyhead(),ui->listWidget->parentWidget());
//            QListWidgetItem* item = new QListWidgetItem(ui->listWidget);
//            dealMessage(messageW, item, recvList[4], time, QNChatMessage::User_She);
//            ui->listWidget->setCurrentRow(ui->listWidget->count()-1);
//        }
//    }
//    if(recvList[0] == "12"){
//        //弹出对话框
//        QMessageBox msg;
//        QString tem = "对方向您发送文件<"+recvList[3]+">,是否确认接受？";
//        msg.setText(tem);
//        QAbstractButton *confirmButton = msg.addButton(tr("确定"), QMessageBox::ActionRole);
//        QAbstractButton *cancelButton = msg.addButton(tr("取消"), QMessageBox::ActionRole);
//        msg.exec();
//        //如果确定
//        if(msg.clickedButton() == confirmButton){
//            QMessageBox::information(this,"提示","请选择保存文件的位置和文件名");
//        }
//        //如果取消则跳出函数
//        else
//            return;

//        QString path = QFileDialog::getSaveFileName(this,tr("save"),"");
//        QStringList fList = path.split("/");
//        QString fileName = fList[fList.length()-1];
//       // QFile file(path+"/"+filename);
//        QFile file(path);
//        //if (data.open(QIODevice::ReadWrite|QIODevice::Truncate))
//        if (file.open(QIODevice::ReadWrite))
//        {
//            QTextStream stream(&file);
//            stream << recvList[5];
//          //  data.write(recvList[6]);
//            //file.close();
//        }
//        else{
//            qDebug() << file.errorString();
//        }
//    }
//}

void MainWindow::on_sendFileButton_clicked()
{

    QString path = QFileDialog::getOpenFileName(this, tr("Open File"),"");
    QFile file(path);
    QByteArray readArray;
    QStringList fList = path.split("/");
    QString fileName = fList[fList.length()-1];
    //如果点击打开
    if(file.open(QIODevice::ReadWrite)){
        QMessageBox msg;
        msg.setText(tr("确定发送文件？"));
        QAbstractButton *confirmButton = msg.addButton(tr("确定"), QMessageBox::ActionRole);
        QAbstractButton *cancelButton = msg.addButton(tr("取消"), QMessageBox::ActionRole);
        msg.exec();
        //如果确定
        if(msg.clickedButton() == confirmButton){
            QString msg = "我发送了文件 <" + fileName +">";
            QString time = QString::number(QDateTime::currentDateTime().toTime_t()); //时间戳
            dealMessageTime(time);
            QString tem = "#|3|" + uName +"|" + myfriend + msg + "|&";
            //client->write(tem.toUtf8());
            emit sendChatRecvMsgSig(tem);
            QNChatMessage* messageW = new QNChatMessage(MainWindow::selectmyfriendhead(), MainWindow::selectmyhead(), ui->listWidget->parentWidget());
            QListWidgetItem* item = new QListWidgetItem(ui->listWidget);
            dealMessage(messageW, item, msg, time, QNChatMessage::User_Me);
            ui->listWidget->setCurrentRow(ui->listWidget->count()-1);
        }
        //如果取消则跳出函数
        else
            return;
    }

    int i = 1;
    while(true)
    {
        readArray = file.read(1000024);
        qDebug()<<readArray.size();
        if(readArray.size() == 0)
        {
            file.close();
            break;
        }
        QString sendBuf = "#|12|" + uName + "|" + myfriend + "|" + fileName + "|" + QString::number(i) + "|" + QString(readArray) + "|&";
        //client->write(sendBuf.toUtf8());

        emit sendFileRecvMsgSig(sendBuf);
        //client->write(sendBuf.toLocal8Bit());
        i++;
    }

}



void MainWindow::dealMessage(QNChatMessage *messageW, QListWidgetItem *item, QString text, QString time,  QNChatMessage::User_Type type)
{
    messageW->setFixedWidth(this->width());
    QSize size = messageW->fontRect(text);
    item->setSizeHint(size);
    messageW->setText(text, time, size, type);
    ui->listWidget->setItemWidget(item, messageW);
}

void MainWindow::dealMessageTime(QString curMsgTime)
{
    bool isShowTime = false;
    if(ui->listWidget->count() > 0) {
        QListWidgetItem* lastItem = ui->listWidget->item(ui->listWidget->count() - 1);
        QNChatMessage* messageW = (QNChatMessage*)ui->listWidget->itemWidget(lastItem);
        int lastTime = messageW->time().toInt();
        int curTime = curMsgTime.toInt();
        qDebug() << "curTime lastTime:" << curTime - lastTime;
        isShowTime = ((curTime - lastTime) > 60); // 两个消息相差一分钟
//        isShowTime = true;
    } else {
        isShowTime = true;
    }
    if(isShowTime) {
        QNChatMessage* messageTime = new QNChatMessage(ui->listWidget->parentWidget());
        QListWidgetItem* itemTime = new QListWidgetItem(ui->listWidget);

        QSize size = QSize(this->width(), 40);
        messageTime->resize(size);
        itemTime->setSizeHint(size);
        messageTime->setText(curMsgTime, curMsgTime, size, QNChatMessage::User_Time);
        ui->listWidget->setItemWidget(itemTime, messageTime);
    }
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    Q_UNUSED(event);


        ui->textEdit->resize(this->width() - 120, ui->widget->height() - 20);
        ui->textEdit->move(10, 10);

        ui->pushButton->move(ui->textEdit->width()+ui->textEdit->x() - ui->pushButton->width() +90,
                             ui->textEdit->height()+ui->textEdit->y() - ui->pushButton->height() );
        ui->sendFileButton->move(ui->textEdit->width()+ui->textEdit->x() - ui->pushButton->width() +90,
                             ui->textEdit->height()+ui->textEdit->y() - ui->pushButton->height() - 40);


    for(int i = 0; i < ui->listWidget->count(); i++) {
        QNChatMessage* messageW = (QNChatMessage*)ui->listWidget->itemWidget(ui->listWidget->item(i));
        QListWidgetItem* item = ui->listWidget->item(i);

        dealMessage(messageW, item, messageW->text(), messageW->time(), messageW->userType());
    }
}
//返回头像地址
QPixmap MainWindow::selectmyhead(){
    if(MainWindow::myhead=="0")
        return QPixmap(":/res/resource/touxiang/0.bmp");
    else if(MainWindow::myhead=="1")
        return QPixmap(":/res/resource/touxiang/1.bmp");
        //return QPixmap(":/res/resource/background/background3.png");
    else if(MainWindow::myhead=="2")
        return QPixmap(":/res/resource/touxiang/2.bmp");
    else if(MainWindow::myhead=="3")
        return QPixmap(":/res/resource/touxiang/3.bmp");
    else if(MainWindow::myhead=="4")
        return QPixmap(":/res/resource/touxiang/4.bmp");
    else if(MainWindow::myhead=="5")
        return QPixmap(":/res/resource/touxiang/5.bmp");
}
QPixmap MainWindow::selectmyfriendhead(){
    if(MainWindow::myhead=="0")
        return QPixmap(":/res/resource/touxiang/0.bmp");
    else if(MainWindow::myfriendhead=="1")
        return QPixmap(":/res/resource/touxiang/1.bmp");
        //return QPixmap(":/resource/background/background3.png");
    else if(MainWindow::myfriendhead=="2")
        return QPixmap(":/res/resource/touxiang/2.bmp");
    else if(MainWindow::myfriendhead=="3")
        return QPixmap(":/res/resource/touxiang/3.bmp");
    else if(MainWindow::myfriendhead=="4")
        return QPixmap(":/res/resource/touxiang/4.bmp");
    else if(MainWindow::myfriendhead=="5")
        return QPixmap(":/res/resource/touxiang/5.bmp");
}

void MainWindow::handChatRecvMsg(QString msg)
{
    QStringList recvList = msg.split('|');
    if(recvList[1] == "0")
    {
        QDateTime dateTime= QDateTime::currentDateTime();//获取系统当前的时间
        //QString timeStr = dateTime .toString("MM-dd hh:mm \n");//格式化时间
        //ui->textEdit->append(timeStr + recvList[2] + ": " + recvList[4]);
        if(recvList[4] != "") {
        QString time = QString::number(QDateTime::currentDateTime().toTime_t()); //时间戳
        dealMessageTime(time);

        QNChatMessage* messageW = new QNChatMessage(MainWindow::selectmyfriendhead(),MainWindow::selectmyhead(),ui->listWidget->parentWidget());
        QListWidgetItem* item = new QListWidgetItem(ui->listWidget);
        dealMessage(messageW, item, recvList[4], time, QNChatMessage::User_She);
        ui->listWidget->setCurrentRow(ui->listWidget->count()-1);
        }
    }

}

void MainWindow::handFileRecvMsg(QString msg)
{
    qDebug()<<"already hand";
    QStringList recvList = msg.split('|');
    //弹出对话框
    QMessageBox msgg;
    QString tem = "对方向您发送文件<"+recvList[3]+">,是否确认接受？";
    msgg.setText(tem);
    QAbstractButton *confirmButton = msgg.addButton(tr("确定"), QMessageBox::ActionRole);
    QAbstractButton *cancelButton = msgg.addButton(tr("取消"), QMessageBox::ActionRole);
    msgg.exec();
    //如果确定
    if(msgg.clickedButton() == confirmButton){
        QMessageBox::information(this,"提示","请选择保存文件的位置和文件名");
    }
    //如果取消则跳出函数
    else
        return;

    QString path = QFileDialog::getSaveFileName(this,tr("save"),"");
    QStringList fList = path.split("/");
    QString fileName = fList[fList.length()-1];
   // QFile file(path+"/"+filename);
    QFile file(path);
    //if (data.open(QIODevice::ReadWrite|QIODevice::Truncate))
    if (file.open(QIODevice::ReadWrite))
    {
        QTextStream stream(&file);
        stream << recvList[5];
      //  data.write(recvList[6]);
        //file.close();
    }
    else{
        qDebug() << file.errorString();
    }
}

/*
QPixmap MainWindow::selectmyhead(){
    if(MainWindow::myhead==1)
        return QPixmap(":/img/Customer Copy.png");
    else if(MainWindow::myhead==2)
        return QPixmap(":/img/CustomerService.png");
    else if(MainWindow::myhead==3)
        return QPixmap(":/img/3.jpg");
    else if(MainWindow::myhead==4)
        return QPixmap(":/img/4.jpg");
    else if(MainWindow::myhead==5)
        return QPixmap(":/img/5.jpg");
}
QPixmap MainWindow::selectmyfriendhead(){
    if(MainWindow::myfriendhead==1)
        return QPixmap(":/img/Customer Copy.png");
    else if(MainWindow::myfriendhead==2)
        return QPixmap(":/img/CustomerService.png");
    else if(MainWindow::myfriendhead==3)
        return QPixmap(":/img/3.jpg");
    else if(MainWindow::myfriendhead==4)
        return QPixmap(":/img/4.jpg");
    else if(MainWindow::myfriendhead==5)
        return QPixmap(":/img/5.jpg");
}
*/
