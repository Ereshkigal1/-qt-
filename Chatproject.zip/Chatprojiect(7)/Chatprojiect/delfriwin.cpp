#include "delfriwin.h"
#include "ui_delfriwin.h"

DelFriWin::DelFriWin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DelFriWin)
{
    ui->setupUi(this);
}

DelFriWin::DelFriWin(QTcpSocket *sock, QString passuName, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DelFriWin)
{
    ui->setupUi(this);
    client = sock;
    uName = passuName;
}

DelFriWin::~DelFriWin()
{
    delete ui;
}

void DelFriWin::on_pushButton_clicked()
{
    QString friuName = ui->lineEdit->text();
    QString packData = "#|9|" + uName + "|" + friuName +"|&";
    client->write(packData.toUtf8());
}
