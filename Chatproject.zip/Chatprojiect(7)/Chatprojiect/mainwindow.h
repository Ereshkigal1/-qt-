/*#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QDebug>
#include <QMessageBox>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    explicit MainWindow(QTcpSocket *sock, QString passuName, QString passfriuName, QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();
    void handReadyRead();

private:
    Ui::MainWindow *ui;
    QTcpSocket *client;
    QString uName;
    QString friuName;
};

#endif // MAINWINDOW_H
*/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QDebug>
#include <QMessageBox>
#include <QFile>
#include <QListWidgetItem>
#include "qnchatmessage.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    //explicit MainWindow(QTcpSocket *sock, QWidget *parent = 0);
    explicit MainWindow(QString passmyfriend, QString myfriendhead, QString passuName, QString myhead, QWidget *parent = 0);
    ~MainWindow();
    void dealMessage(QNChatMessage *messageW, QListWidgetItem *item, QString text, QString time, QNChatMessage::User_Type type);
    void dealMessageTime(QString curMsgTime);
    QPixmap selectmyhead();
    QPixmap selectmyfriendhead();
protected:
    void resizeEvent(QResizeEvent *event);

private slots:
    void on_pushButton_clicked();
    //void handReadyRead();
    void on_sendFileButton_clicked();
    void handChatRecvMsg(QString msg);
    void handFileRecvMsg(QString msg);

signals:
    void sendChatRecvMsgSig(QString);
    void sendFileRecvMsgSig(QString);

private:
    Ui::MainWindow *ui;
    QString uName;
    QString myfriend;
    QString myhead;
    QString myfriendhead;
/*
    QFile *localFile;
    QString fileName;  //文件名

    QByteArray outBlock;  //分次传
        qint64 loadSize;  //每次发送数据的大小
        qint64 byteToWrite;  //剩余数据大小
        qint64 totalSize;  //文件总大小
*/

};

#endif // MAINWINDOW_H
