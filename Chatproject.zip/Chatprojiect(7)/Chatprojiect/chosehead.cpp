#include "chosehead.h"
#include "ui_chosehead.h"

ChoseHead::ChoseHead(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ChoseHead)
{
    ui->setupUi(this);
    connect(ui->pushButton,&QPushButton::released,this,&ChoseHead::SendSlot);

}

ChoseHead::~ChoseHead()
{
    delete ui;
}

QString nHead = "0";

void ChoseHead::on_pushButton_2_clicked()
{
    nHead = "0";
    ui->pushButton->setEnabled(true);
}

void ChoseHead::on_pushButton_3_clicked()
{
    nHead = "1";
    ui->pushButton->setEnabled(true);
}

void ChoseHead::on_pushButton_4_clicked()
{
    nHead = "2";
    ui->pushButton->setEnabled(true);
}

void ChoseHead::on_pushButton_5_clicked()
{
    nHead = "3";
    ui->pushButton->setEnabled(true);
}

void ChoseHead::on_pushButton_6_clicked()
{
    nHead = "4";
    ui->pushButton->setEnabled(true);
}

void ChoseHead::on_pushButton_7_clicked()
{
    nHead = "5";
    ui->pushButton->setEnabled(true);
}

void ChoseHead::SendSlot()
{
    emit SendData(nHead);
    close();
}
