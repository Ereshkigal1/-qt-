#ifndef CHOSEHEAD_H
#define CHOSEHEAD_H

#include <QDialog>
#include <QTcpSocket>
#include<QDebug>
#include<QMessageBox>


namespace Ui {
class ChoseHead;
}

class ChoseHead : public QDialog
{
    Q_OBJECT

public:
    explicit ChoseHead(QWidget *parent = 0);
    explicit ChoseHead(QTcpSocket* sock, QWidget *parent = 0);
    ~ChoseHead();

private slots:
    void SendSlot();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

private:
    Ui::ChoseHead *ui;
    QTcpSocket *client;

signals:
    void SendData(QString str);
};

#endif // CHOSEHEAD_H
