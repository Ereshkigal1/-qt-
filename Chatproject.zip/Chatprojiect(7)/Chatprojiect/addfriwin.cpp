#include "addfriwin.h"
#include "ui_addfriwin.h"

AddFriWin::AddFriWin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddFriWin)
{
    ui->setupUi(this);
}

AddFriWin::AddFriWin(QTcpSocket *sock, QString passuName, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddFriWin)
{
    ui->setupUi(this);
    client = sock;
    uName = passuName;
}

AddFriWin::~AddFriWin()
{
    delete ui;
}

void AddFriWin::on_pushButton_clicked()
{
    QString friuName = ui->friUName->text();
    QString testMsg = ui->testMsg->text();
    QString groupMsg = ui->groupMsg->text();
    QString packData;

    if(groupMsg == "我的好友")
    {
        packData = "#|4|" + uName + "|" + friuName + "|1|" + testMsg + "|&";
        client->write(packData.toUtf8());
    }
    else if(groupMsg == "我的家人")
    {
        packData = "#|4|" + uName + "|" + friuName + "|2|" + testMsg + "|&";
        client->write(packData.toLocal8Bit());
    }
    else
    {
        QMessageBox::warning(this, "警告", "分组不存在");
    }
}


