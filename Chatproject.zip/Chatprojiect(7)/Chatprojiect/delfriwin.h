#ifndef DELFRIWIN_H
#define DELFRIWIN_H

#include <QWidget>
#include <QDebug>
#include <QMessageBox>
#include <QTcpSocket>

namespace Ui {
class DelFriWin;
}

class DelFriWin : public QWidget
{
    Q_OBJECT

public:
    explicit DelFriWin(QWidget *parent = 0);
    explicit DelFriWin(QTcpSocket *sock, QString passuName, QWidget *parent = 0);
    ~DelFriWin();

private slots:
    void on_pushButton_clicked();

private:
    Ui::DelFriWin *ui;
    QTcpSocket *client;
    QString uName;
};

#endif // DELFRIWIN_H
