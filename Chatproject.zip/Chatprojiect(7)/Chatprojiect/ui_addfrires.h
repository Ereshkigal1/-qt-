/********************************************************************************
** Form generated from reading UI file 'addfrires.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDFRIRES_H
#define UI_ADDFRIRES_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AddFriRes
{
public:
    QLabel *label;
    QPushButton *agreeBtn;
    QPushButton *rejectBtn;
    QLabel *label_2;
    QLabel *testMsg;

    void setupUi(QWidget *AddFriRes)
    {
        if (AddFriRes->objectName().isEmpty())
            AddFriRes->setObjectName(QStringLiteral("AddFriRes"));
        AddFriRes->resize(294, 159);
        AddFriRes->setStyleSheet(QStringLiteral("#AddFriRes{border-image: url(:/res/resource/background/backgroud8.jfif);}"));
        label = new QLabel(AddFriRes);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(0, 10, 291, 40));
        QFont font;
        font.setPointSize(11);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);
        agreeBtn = new QPushButton(AddFriRes);
        agreeBtn->setObjectName(QStringLiteral("agreeBtn"));
        agreeBtn->setGeometry(QRect(40, 110, 75, 23));
        rejectBtn = new QPushButton(AddFriRes);
        rejectBtn->setObjectName(QStringLiteral("rejectBtn"));
        rejectBtn->setGeometry(QRect(180, 109, 75, 23));
        label_2 = new QLabel(AddFriRes);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(120, 50, 54, 20));
        testMsg = new QLabel(AddFriRes);
        testMsg->setObjectName(QStringLiteral("testMsg"));
        testMsg->setGeometry(QRect(10, 70, 271, 21));
        testMsg->setAlignment(Qt::AlignCenter);

        retranslateUi(AddFriRes);

        QMetaObject::connectSlotsByName(AddFriRes);
    } // setupUi

    void retranslateUi(QWidget *AddFriRes)
    {
        AddFriRes->setWindowTitle(QApplication::translate("AddFriRes", "Form", Q_NULLPTR));
        label->setText(QApplication::translate("AddFriRes", "\345\225\212\345\223\210\345\223\210\345\223\210", Q_NULLPTR));
        agreeBtn->setText(QApplication::translate("AddFriRes", "\345\220\214\346\204\217", Q_NULLPTR));
        rejectBtn->setText(QApplication::translate("AddFriRes", "\346\213\222\347\273\235", Q_NULLPTR));
        label_2->setText(QApplication::translate("AddFriRes", "\351\252\214\350\257\201\344\277\241\346\201\257", Q_NULLPTR));
        testMsg->setText(QApplication::translate("AddFriRes", "TextLabel", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class AddFriRes: public Ui_AddFriRes {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDFRIRES_H
