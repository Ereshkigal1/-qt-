#include "frilistwindow.h"
#include "ui_frilistwindow.h"

FriListWindow::FriListWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FriListWindow)
{
    ui->setupUi(this);
}

FriListWindow::FriListWindow(QTcpSocket *sock, QString passuName, QString passicon, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FriListWindow)
{
    ui->setupUi(this);
    nfri = 0;
    nfam = 0;
    addWin = NULL;
    delWin = NULL;
    addRes = NULL;
    client = sock;
    uName = passuName;
    icon = passicon;
    int j = 0;
    for(j = 0; j < 40; j++)
    {
        fricon[j].myFriName = "0";
    }
    connect(client, SIGNAL(readyRead()), this, SLOT(handReadyRead()));
    initFriLsit();
    client->write("#|run|&");

}



FriListWindow::~FriListWindow()
{
    delete ui;
}

void FriListWindow::initFriLsit()
{
    QString iconStr = "D:/qtProject/Chatprojiect/resource/touxiang/" + icon + ".bmp";
    ui->userHead->setIcon(QPixmap(iconStr));
    ui->userHead->setIconSize(QPixmap(iconStr).size());
    ui->label->setText(uName);

    layout1 = new QVBoxLayout((QGroupBox*)ui->myfri);
    layout1->setMargin(10);
    layout1->setAlignment(Qt::AlignHCenter);
    ui->FriListBox->setItemText(0, tr("我的好友"));


    layout2 = new QVBoxLayout((QGroupBox*)ui->myfim);
    layout2->setMargin(10);
    layout2->setAlignment(Qt::AlignHCenter);
    ui->FriListBox->setItemText(1, tr("我的家人"));
}


void FriListWindow::addFriend(QString tooluName, QString icon, QString ifOnline)
{
    QString iconStr = "D:/qtProject/Chatprojiect/resource/touxiang/" + icon + ".bmp";
    QString ifOnlineMsg;
    int x = 0;
    if(ifOnline == "online")
    {
        x = 1;
        ifOnlineMsg = "在线";
    }
    else
    {
        x = 0;
        ifOnlineMsg = "离线";
    }
    QString toolStr = tooluName + "<" + ifOnlineMsg + ">";
    int i = 0;
    for(i = 0; i < nfri; i++)
    {
        if(toolBtn1[i] == NULL)
        {
            toolBtn1[i] = new QToolButton;
            toolBtn1[i]->setText(toolStr);
            toolBtn1[i]->setIcon(QPixmap(iconStr));
            toolBtn1[i]->setIconSize(QPixmap(iconStr).size());
            toolBtn1[i]->setAutoRaise(true);
            toolBtn1[i]->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
            if(x == 1)
                toolBtn1[i]->setEnabled(true);
            else
                toolBtn1[i]->setEnabled(false);
            layout1->addWidget(toolBtn1[i]);

            toolBtn1[i]->setObjectName(tooluName);
            connect(toolBtn1[i], SIGNAL(clicked()), this, SLOT(on_pushToolButton_clicked()));
            break;
        }
    }
    if(i == nfri)
    {
        toolBtn1[nfri] = new QToolButton;
        toolBtn1[nfri]->setText(toolStr);
        toolBtn1[nfri]->setIcon(QPixmap(iconStr));
        toolBtn1[nfri]->setIconSize(QPixmap(iconStr).size());
        toolBtn1[nfri]->setAutoRaise(true);
        toolBtn1[nfri]->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        qDebug()<<x;
        if(x == 1)
        {
            toolBtn1[i]->setEnabled(true);
            qDebug()<<"hahaha";
        }
        else
            toolBtn1[i]->setEnabled(false);
        layout1->addWidget(toolBtn1[nfri]);

        toolBtn1[nfri]->setObjectName(tooluName);
        connect(toolBtn1[nfri], SIGNAL(clicked()), this, SLOT(on_pushToolButton_clicked()));

        nfri++;
    }

    int j = 0;
    for(j = 0; j < nFricon; j++)
    {
        if(fricon[j].myFriName == "0")
        {
            fricon[j].myFriName = tooluName;
            fricon[j].myFriIcon = icon;
            break;
        }
    }
    if(j == nFricon)
    {
        fricon[nFricon].myFriName = tooluName;
        fricon[nFricon].myFriIcon = icon;
    }
    nFricon++;
}

void FriListWindow::addFamily(QString tooluName, QString icon, QString ifOnline)
{
    QString iconStr = "D:/qtProject/Chatprojiect/resource/touxiang/" + icon + ".bmp";
    QString ifOnlineMsg;
    int x = 0;
    if(ifOnline == "online")
    {
        x = 1;
        ifOnlineMsg = "在线";
    }
    else
    {
        x = 0;
        ifOnlineMsg = "离线";
    }
    QString toolStr = tooluName + "<" + ifOnlineMsg + ">";
    int i = 0;
    for(i = 0; i < nfam; i++)
    {
        if(toolBtn2[i] == NULL)
        {
            toolBtn2[i] = new QToolButton;
            toolBtn2[i]->setText(toolStr);
            toolBtn2[i]->setIcon(QPixmap(iconStr));
            toolBtn2[i]->setIconSize(QPixmap(iconStr).size());
            toolBtn2[i]->setAutoRaise(true);
            toolBtn2[i]->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
            if(x == 1)
                toolBtn2[i]->setEnabled(true);
            else
                toolBtn2[i]->setEnabled(false);
            layout2->addWidget(toolBtn2[i]);

            toolBtn2[i]->setObjectName(tooluName);
            connect(toolBtn2[i], SIGNAL(clicked()), this, SLOT(on_pushToolButton_clicked()));
            break;
        }
    }
    if(i == nfam)
    {
        toolBtn2[nfam] = new QToolButton;
        toolBtn2[nfam]->setText(toolStr);
        toolBtn2[nfam]->setIcon(QPixmap(iconStr));
        toolBtn2[nfam]->setIconSize(QPixmap(iconStr).size());
        toolBtn2[nfam]->setAutoRaise(true);
        toolBtn2[nfam]->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        if(x == 1)
            toolBtn2[i]->setEnabled(true);
        else
            toolBtn2[i]->setEnabled(false);
        layout2->addWidget(toolBtn2[nfam]);

        toolBtn2[nfam]->setObjectName(tooluName);
        connect(toolBtn2[nfam], SIGNAL(clicked()), this, SLOT(on_pushToolButton_clicked()));
        nfam++;
    }
    int j = 0;
    for(j = 0; j < nFricon; j++)
    {
        if(fricon[j].myFriName == "0")
        {
            fricon[j].myFriName = tooluName;
            fricon[j].myFriIcon = icon;
            break;
        }
    }
    if(j == nFricon)
    {
        fricon[nFricon].myFriName = tooluName;
        fricon[nFricon].myFriIcon = icon;
    }
    nFricon++;
}

void FriListWindow::removeFriend(QString delTooluName)
{
    int p = 0;
    int i = 0;
    for(i = 0; i < nfri; i++)
    {
        if(toolBtn1[i] == NULL)
            continue;
        QString toolText = toolBtn1[i]->text();
        QStringList toolTextList = toolText.split('<');
        QString tooluName = toolTextList[0];
        if(tooluName == delTooluName)
        {
            toolBtn1[i]->close();
            layout1->removeWidget(toolBtn1[i]);
            toolBtn1[i] = NULL;
            p = 1;
            break;
        }
     }
    if(p == 0)
    {
        for(i = 0; i < nfam; i++)
        {
            if(toolBtn2[i] == NULL)
                continue;
            QString toolText = toolBtn2[i]->text();
            QStringList toolTextList = toolText.split('<');
            QString tooluName = toolTextList[0];
            if(tooluName == delTooluName)
            {
                toolBtn2[i]->close();
                layout2->removeWidget(toolBtn2[i]);
                toolBtn2[i] = NULL;
                break;
            }
        }
    }
    int j = 0;
    for(j = 0; j < nFricon; j++)
    {
        if(fricon[j].myFriName == "0")
            continue;
        if(fricon[j].myFriName == delTooluName)
        {
            fricon[j].myFriName = "0";
            fricon[j].myFriIcon = "";
            break;
        }
    }
}

QString FriListWindow::geticon(QString name)
{
    int j = 0;
    for(j = 0; j < nFricon; j++)
    {
        if(fricon[j].myFriName == name)
        {
            return fricon[j].myFriIcon;
        }
    }
    return "0";
}

void FriListWindow::on_addFriBtn_clicked()
{
    addWin = NULL;
    addWin = new AddFriWin(client, uName);
    addWin->show();
}

void FriListWindow::on_pushToolButton_clicked()
{
    qDebug()<<sender()->objectName();
    QString friuName = sender()->objectName();
    if(chatWin != NULL)
    {
        chatWin->close();
        chatWin = NULL;
    }
    qDebug()<<"hah"<<uName;
    qDebug()<<"haha"<<friuName;
    //disconnect(client, SIGNAL(readyRead()), 0, 0);
    chatWin = new MainWindow(friuName, geticon(friuName), uName, icon);
    connect(this, SIGNAL(sendChatRecvMsgSig(QString)), chatWin, SLOT(handChatRecvMsg(QString)));
    connect(chatWin, SIGNAL(sendChatRecvMsgSig(QString)), this, SLOT(handChatRecvMsg(QString)));
    connect(this, SIGNAL(sendFileRecvMsgSig(QString)), chatWin, SLOT(handFileRecvMsg(QString)));
    connect(chatWin, SIGNAL(sendFileRecvMsgSig(QString)), this, SLOT(handFileRecvMsg(QString)));
    chatWin->show();
}

void FriListWindow::handReadyRead()
{
    QByteArray recvArray = client->readAll();
    if(recvArray.at(0) != '#' || recvArray.at(recvArray.size()-1) != '&')
        return;
    QString recvStr = QString::fromUtf8(recvArray);
    recvStr = recvStr.mid(2, recvStr.length()-4);
    QStringList recvList = recvStr.split('|');

    if(recvList[0] == "4")
    {
        if(recvList[1] == "0")
        {
            QMessageBox::information(this, "提示", "请求已发送");
            addWin->close();
            addWin = NULL;
        }
        else
        {
            QMessageBox::information(this, "提示", "发送失败");
        }
    }
    else if(recvList[0] == "3")
    {
        qDebug()<<"emit send";
        emit sendChatRecvMsgSig(recvStr);
    }
    else if(recvList[0] == '5')
    {
        QString friuName = recvList[1];
        QString testMsg = recvList[2];
        QString groupMsg = recvList[3];
        addRes = NULL;
        addRes = new AddFriRes(client, uName, friuName, testMsg, groupMsg);
        addRes->show();
        addRes = NULL;
    }
    else if(recvList[0] == '6')
    {
        QString friuName = recvList[1];
        QString groupMsg = recvList[2];
        QString ifOnline = recvList[3];
        QString icon = recvList[4];
        if(groupMsg == "1")
            addFriend(friuName, icon, ifOnline);
        else if(groupMsg == "2")
            addFamily(friuName, icon, ifOnline);
    }
    else if(recvList[0] == '7')
    {
        QString friuName = recvList[1];
        QString groupMsg = recvList[2];
        QString ifOnline = recvList[3];
        QString icon = recvList[4];
        if(groupMsg == "1")
            addFriend(friuName, icon, ifOnline);
        else if(groupMsg == "2")
            addFamily(friuName, icon, ifOnline);
    }
    else if(recvList[0] == '8')
    {
        int x = 0;
        int i = 0;
        for(i = 0; i < nfri; i++)
        {
            if(toolBtn1[i] == NULL)
                continue;
            QString toolText = toolBtn1[i]->text();
            QStringList toolTextList = toolText.split('<');
            QString tooluName = toolTextList[0];
            if(tooluName == recvList[1])
            {
                QString ifOnlineMsg;
                if(recvList[2] == "online")
                {
                    x = 1;
                    ifOnlineMsg = "在线";
                }
                else
                {
                    x = 0;
                    ifOnlineMsg = "离线";
                }
                QString toolStr = tooluName + "<" + ifOnlineMsg + ">";
                toolBtn1[i]->setText(toolStr);
                if(x == 1)
                    toolBtn1[i]->setEnabled(true);
                else
                    toolBtn1[i]->setEnabled(false);
                break;
            }
        }

        x = 0;
        i = 0;
        for(i = 0; i < nfam; i++)
        {
            if(toolBtn2[i] == NULL)
                continue;
            QString toolText = toolBtn2[i]->text();
            QStringList toolTextList = toolText.split('<');
            QString tooluName = toolTextList[0];
            if(tooluName == recvList[1])
            {
                QString ifOnlineMsg;
                if(recvList[3] == "online")
                {
                    x = 1;
                    ifOnlineMsg = "在线";
                }
                else
                {
                    x = 0;
                    ifOnlineMsg = "离线";
                }
                QString toolStr = tooluName + "<" + ifOnlineMsg + ">";
                toolBtn2[i]->setText(toolStr);
                if(x == 1)
                    toolBtn2[i]->setEnabled(true);
                else
                    toolBtn2[i]->setEnabled(false);
                break;
            }
        }
    }
    else if(recvList[0] == '9')
    {
        removeFriend(recvList[1]);
        if(delWin != NULL)
        {
            QMessageBox::information(this, "提示", "删除成功");
            delWin->close();
            delWin = NULL;
        }
    }
    else if(recvList[0] == "12")
    {
        qDebug()<<"recv emit";
        emit sendFileRecvMsgSig(recvStr);
    }
}

void FriListWindow::on_delFriBtn_clicked()
{
    delWin = new DelFriWin(client, uName);
    delWin->show();
}

void FriListWindow::handChatRecvMsg(QString msg)
{
    client->write(msg.toUtf8());
}

void FriListWindow::handFileRecvMsg(QString msg)
{
    qDebug()<<"file send";
    client->write(msg.toUtf8());
}
