#ifndef FRILISTWINDOW_H
#define FRILISTWINDOW_H

#include <QWidget>
#include <QToolBox>
#include <QToolButton>
#include <QGroupBox>
#include <QVBoxLayout>
#include <QPixmap>
#include <QTcpSocket>
#include <QDebug>
#include <QMessageBox>
#include "addfriwin.h"
#include "addfrires.h"
#include "mainwindow.h"
#include "delfriwin.h"


namespace Ui {
class FriListWindow;
}

struct Uicon{
    QString myFriName;
    QString myFriIcon;
};

class FriListWindow : public QWidget
{
    Q_OBJECT

public:
    explicit FriListWindow(QWidget *parent = 0);
    explicit FriListWindow(QTcpSocket *sock, QString passuName, QString passicon = "0", QWidget *parent = 0);
    void addFriend(QString tooluName, QString icon, QString ifOnline);
    void addFamily(QString tooluName, QString icon, QString ifOnline);
    void removeFriend(QString tooluName);
    QString geticon(QString name);
    void initFriLsit();
    ~FriListWindow();

private slots:
    void on_addFriBtn_clicked();
    void handReadyRead();
    void on_pushToolButton_clicked();

    void on_delFriBtn_clicked();

    void handChatRecvMsg(QString msg);
    void handFileRecvMsg(QString msg);

signals:
    void sendChatRecvMsgSig(QString);
    void sendFileRecvMsgSig(QString);

private:
    Ui::FriListWindow *ui;
    QGroupBox *groupBox1;
    QGroupBox *groupBox2;
    QVBoxLayout *layout1;
    QVBoxLayout *layout2;
    QVBoxLayout *layout3;
    QToolButton *toolBtn1[50] = {NULL};
    QToolButton *toolBtn2[50] = {NULL};
    int nfri = 0;
    int nfam = 0;
    QTcpSocket *client;
    AddFriWin *addWin = NULL;
    AddFriRes *addRes = NULL;
    QString uName;
    QString icon;
    MainWindow *chatWin = NULL;
    DelFriWin *delWin = NULL;
    int nChatWin = 0;
    struct Uicon fricon[50];
    int nFricon = 0;
};

#endif // FRILISTWINDOW_H
