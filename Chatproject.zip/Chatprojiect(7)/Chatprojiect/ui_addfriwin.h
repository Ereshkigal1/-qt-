/********************************************************************************
** Form generated from reading UI file 'addfriwin.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDFRIWIN_H
#define UI_ADDFRIWIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AddFriWin
{
public:
    QLabel *label;
    QLineEdit *friUName;
    QLabel *label_2;
    QLineEdit *testMsg;
    QLabel *label_3;
    QLineEdit *groupMsg;
    QPushButton *pushButton;

    void setupUi(QWidget *AddFriWin)
    {
        if (AddFriWin->objectName().isEmpty())
            AddFriWin->setObjectName(QStringLiteral("AddFriWin"));
        AddFriWin->resize(345, 208);
        AddFriWin->setStyleSheet(QStringLiteral("#AddFriWin{border-image: url(:/res/resource/background/backgroud8.jfif);}"));
        label = new QLabel(AddFriWin);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(40, 35, 91, 20));
        friUName = new QLineEdit(AddFriWin);
        friUName->setObjectName(QStringLiteral("friUName"));
        friUName->setGeometry(QRect(150, 35, 141, 21));
        label_2 = new QLabel(AddFriWin);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(53, 77, 50, 16));
        testMsg = new QLineEdit(AddFriWin);
        testMsg->setObjectName(QStringLiteral("testMsg"));
        testMsg->setGeometry(QRect(151, 75, 141, 21));
        label_3 = new QLabel(AddFriWin);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(53, 118, 54, 12));
        groupMsg = new QLineEdit(AddFriWin);
        groupMsg->setObjectName(QStringLiteral("groupMsg"));
        groupMsg->setGeometry(QRect(151, 115, 141, 21));
        pushButton = new QPushButton(AddFriWin);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(125, 160, 81, 31));

        retranslateUi(AddFriWin);

        QMetaObject::connectSlotsByName(AddFriWin);
    } // setupUi

    void retranslateUi(QWidget *AddFriWin)
    {
        AddFriWin->setWindowTitle(QApplication::translate("AddFriWin", "Form", Q_NULLPTR));
        label->setText(QApplication::translate("AddFriWin", "\346\203\263\346\267\273\345\212\240\347\232\204\347\224\250\346\210\267\345\220\215", Q_NULLPTR));
        label_2->setText(QApplication::translate("AddFriWin", "\351\252\214\350\257\201\344\277\241\346\201\257", Q_NULLPTR));
        label_3->setText(QApplication::translate("AddFriWin", "\345\210\206\347\273\204\344\277\241\346\201\257", Q_NULLPTR));
        pushButton->setText(QApplication::translate("AddFriWin", "\345\217\221\351\200\201\350\257\267\346\261\202", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class AddFriWin: public Ui_AddFriWin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDFRIWIN_H
