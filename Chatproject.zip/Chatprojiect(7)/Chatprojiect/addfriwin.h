#ifndef ADDFRIWIN_H
#define ADDFRIWIN_H

#include <QWidget>
#include <QTcpSocket>
#include <QDebug>
#include <QMessageBox>

namespace Ui {
class AddFriWin;
}

class AddFriWin : public QWidget
{
    Q_OBJECT

public:
    explicit AddFriWin(QWidget *parent = 0);
    explicit AddFriWin(QTcpSocket *sock, QString passuName, QWidget *parent = 0);
    ~AddFriWin();

private slots:
    void on_pushButton_clicked();

private:
    Ui::AddFriWin *ui;
    QTcpSocket *client;
    QString uName;
};

#endif // ADDFRIWIN_H
