#ifndef REGISTER_H
#define REGISTER_H

#include <QDialog>
#include<QMessageBox>
#include<QDebug>
#include<QTcpSocket>
#include<chosehead.h>
namespace Ui {
class Register;
}

class Register : public QDialog
{
    Q_OBJECT

public:
    explicit Register(QWidget *parent = 0);
    explicit Register(QTcpSocket* sock, QWidget *parent = 0);
    ~Register();

private slots:
    void on_pushButton_clicked();

    void on_ChoseHeadButton_clicked();
    void GetData(QString str);

private:
    Ui::Register *ui;
    QTcpSocket *client;
    ChoseHead CH;
};

#endif // REGISTER_H
