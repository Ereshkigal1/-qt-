#ifndef LOGIN_H
#define LOGIN_H

#include <QDialog>
#include <QTcpSocket>
#include <QDebug>
#include <QMessageBox>
#include <register.h>
#include <mainwindow.h>
#include "frilistwindow.h"

namespace Ui {
class login;
}

class login : public QDialog
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = 0);
    ~login();

private slots:
    void on_pushButton_clicked();
    void handConnected();
    void handReadyRead();

    void on_pushButton_2_clicked();

private:
    Ui::login *ui;
    QTcpSocket *client;
    Register *reg;
    MainWindow *mv;
    FriListWindow *friList;
};

#endif // LOGIN_H
