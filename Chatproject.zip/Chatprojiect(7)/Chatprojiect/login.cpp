#include "login.h"
#include "ui_login.h"

login::login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
    client = new QTcpSocket();
    client->connectToHost("192.168.0.193", 7788);
    connect(client, SIGNAL(connected()), this, SLOT(handConnected()));

}

login::~login()
{
    delete ui;
}

void login::on_pushButton_clicked()
{
    QString uName = ui->lineEdit->text();
    QString pWord = ui->lineEdit_2->text();
    if(uName.length()==0||pWord.length()==0)
    {
        QMessageBox::information(this,"注意","请输入账号和密码");
        return;
    }
    QString packData = "#|1|" + uName + "|" + pWord + "|&";
    client->write(packData.toUtf8());
}

void login::handConnected()
{
    ui->pushButton->setEnabled(true);
    ui->pushButton_2->setEnabled(true);
    connect(client, SIGNAL(readyRead()), this, SLOT(handReadyRead()));
}

void login::handReadyRead()
{
    QByteArray recvArray = client->readAll();
    if(recvArray.at(0) != '#' || recvArray.at(recvArray.size()-1) != '&')
        return;
    QString recvStr = QString::fromUtf8(recvArray);
    recvStr = recvStr.mid(2, recvStr.length()-4);

    QStringList recvList = recvStr.split('|');
    if(recvList.size() < 3)
        return;
    if(recvList[0] == '1')
    {
        if(recvList[1] == '0')
        {
            QMessageBox::information(this, "提示", "登录成功");
            disconnect(client, SIGNAL(readyRead()), 0, 0);
            friList = new FriListWindow(client, recvList[2], recvList[3]);
            friList->addFriend("Amy", "1", "online");
            friList->addFriend("李四", "1", "online");
            friList->addFriend("Jack", "1", "offline");

            //friList->removeFriend(2);
            //friList->addFriend("张三", "1");
            friList->show();
            this->hide();
        }
        else
        {
            QMessageBox::warning(this, "警告", recvList[2]);
        }
    }
    if(recvList[0] == '2')
    {
        if(recvList[1] == '0')
        {
            QMessageBox::information(this, "提示", "注册成功");
        }
        else
        {
            QMessageBox::warning(this, "警告", recvList[2]);
        }
        reg->close();
        reg = NULL;
    }
}



void login::on_pushButton_2_clicked()
{
    reg = new Register(client);
    reg->show();
}
