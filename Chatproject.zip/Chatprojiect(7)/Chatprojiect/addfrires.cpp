#include "addfrires.h"
#include "ui_addfrires.h"

AddFriRes::AddFriRes(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddFriRes)
{
    ui->setupUi(this);
}

AddFriRes::AddFriRes(QTcpSocket *sock, QString passuName, QString passfriuName, QString passTestMsg, QString passGroupMsg, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddFriRes)
{
    ui->setupUi(this);
    friuName = passfriuName;
    uName = passuName;
    testMsg = passTestMsg;
    groupMsg = passGroupMsg;
    client = sock;
    QString msgStr = friuName + "请求添加你为好友";
    ui->label->setText(msgStr);
    ui->testMsg->setText(testMsg);
}

AddFriRes::~AddFriRes()
{
    delete ui;
}

void AddFriRes::on_agreeBtn_clicked()
{
    QString packData = "#|6|" + friuName + "|" + uName + "|" + groupMsg + "|yes|&";
    client->write(packData.toUtf8());
    this->close();
}

void AddFriRes::on_rejectBtn_clicked()
{
    QString packData = "#|6|" + friuName + "|" + uName + "|" + groupMsg + "|no|&";
    client->write(packData.toUtf8());
    this->close();
}
