/********************************************************************************
** Form generated from reading UI file 'registor.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTOR_H
#define UI_REGISTOR_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Registor
{
public:
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QDateEdit *dateEdit;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QPushButton *pushButton;

    void setupUi(QDialog *Registor)
    {
        if (Registor->objectName().isEmpty())
            Registor->setObjectName(QStringLiteral("Registor"));
        Registor->resize(400, 413);
        lineEdit = new QLineEdit(Registor);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(190, 64, 113, 20));
        lineEdit_2 = new QLineEdit(Registor);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(190, 108, 113, 20));
        lineEdit_3 = new QLineEdit(Registor);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(190, 150, 113, 20));
        lineEdit_4 = new QLineEdit(Registor);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(190, 190, 113, 20));
        dateEdit = new QDateEdit(Registor);
        dateEdit->setObjectName(QStringLiteral("dateEdit"));
        dateEdit->setGeometry(QRect(190, 235, 111, 31));
        label = new QLabel(Registor);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(105, 67, 54, 12));
        label_2 = new QLabel(Registor);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(110, 110, 54, 12));
        label_3 = new QLabel(Registor);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(100, 152, 54, 12));
        label_4 = new QLabel(Registor);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(100, 193, 54, 12));
        label_5 = new QLabel(Registor);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(99, 244, 54, 12));
        pushButton = new QPushButton(Registor);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(150, 320, 81, 31));

        retranslateUi(Registor);

        QMetaObject::connectSlotsByName(Registor);
    } // setupUi

    void retranslateUi(QDialog *Registor)
    {
        Registor->setWindowTitle(QApplication::translate("Registor", "Dialog", Q_NULLPTR));
        label->setText(QApplication::translate("Registor", "\347\224\250\346\210\267\345\220\215", Q_NULLPTR));
        label_2->setText(QApplication::translate("Registor", "\345\257\206 \347\240\201", Q_NULLPTR));
        label_3->setText(QApplication::translate("Registor", "\347\241\256\350\256\244\345\257\206\347\240\201", Q_NULLPTR));
        label_4->setText(QApplication::translate("Registor", "\347\224\265\350\257\235\345\217\267\347\240\201", Q_NULLPTR));
        label_5->setText(QApplication::translate("Registor", "\345\207\272\347\224\237\346\227\245\346\234\237", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Registor", "\347\241\256\350\256\244\346\263\250\345\206\214", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Registor: public Ui_Registor {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTOR_H
