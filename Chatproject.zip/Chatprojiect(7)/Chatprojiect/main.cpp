#include "login.h"
#include "frilistwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);


    login w;
    w.show();



//    QTcpSocket *client;
//    client = new QTcpSocket();
//    client->connectToHost("192.168.0.193", 7788);
//    FriListWindow w(client, "Amy");
//    w.addFriend("张三","1", "online");
//    w.addFriend("李四","1", "online");
//    w.addFriend("jack","1", "offline");
//    w.addFriend("Tom","1", "offline");
//    w.addFamily("Lucy", "4", "offline");

    //w.removeFriend(2);
    //w.addFriend("张三","1");
    w.show();


    return a.exec();
}
