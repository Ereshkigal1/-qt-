/********************************************************************************
** Form generated from reading UI file 'register.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTER_H
#define UI_REGISTER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Register
{
public:
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QDateEdit *dateEdit;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *lineEdit_4;
    QLabel *label_5;
    QPushButton *pushButton;
    QPushButton *ChoseHeadButton;

    void setupUi(QDialog *Register)
    {
        if (Register->objectName().isEmpty())
            Register->setObjectName(QStringLiteral("Register"));
        Register->resize(347, 414);
        QFont font;
        font.setFamily(QStringLiteral("Arial"));
        font.setPointSize(16);
        Register->setFont(font);
        Register->setStyleSheet(QStringLiteral("#Register{border-image: url(:/res/resource/background/backgroud5.jfif);}"));
        lineEdit = new QLineEdit(Register);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(140, 55, 141, 21));
        lineEdit_2 = new QLineEdit(Register);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(141, 110, 141, 20));
        lineEdit_2->setEchoMode(QLineEdit::Password);
        lineEdit_3 = new QLineEdit(Register);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(141, 160, 141, 21));
        lineEdit_3->setEchoMode(QLineEdit::Password);
        dateEdit = new QDateEdit(Register);
        dateEdit->setObjectName(QStringLiteral("dateEdit"));
        dateEdit->setGeometry(QRect(160, 256, 101, 21));
        QFont font1;
        font1.setPointSize(11);
        dateEdit->setFont(font1);
        label = new QLabel(Register);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(80, 50, 54, 31));
        QFont font2;
        font2.setFamily(QStringLiteral("Arial"));
        font2.setPointSize(10);
        label->setFont(font2);
        label_2 = new QLabel(Register);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(78, 100, 54, 31));
        label_2->setFont(font2);
        label_3 = new QLabel(Register);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(60, 150, 111, 31));
        label_3->setFont(font2);
        label_4 = new QLabel(Register);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(59, 255, 61, 21));
        QFont font3;
        font3.setPointSize(10);
        label_4->setFont(font3);
        lineEdit_4 = new QLineEdit(Register);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(142, 210, 141, 21));
        lineEdit_4->setEchoMode(QLineEdit::Normal);
        label_5 = new QLabel(Register);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(60, 200, 111, 31));
        label_5->setFont(font3);
        pushButton = new QPushButton(Register);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setEnabled(false);
        pushButton->setGeometry(QRect(123, 354, 91, 31));
        pushButton->setFont(font3);
        ChoseHeadButton = new QPushButton(Register);
        ChoseHeadButton->setObjectName(QStringLiteral("ChoseHeadButton"));
        ChoseHeadButton->setGeometry(QRect(123, 297, 91, 31));
        ChoseHeadButton->setFont(font3);

        retranslateUi(Register);

        QMetaObject::connectSlotsByName(Register);
    } // setupUi

    void retranslateUi(QDialog *Register)
    {
        Register->setWindowTitle(QApplication::translate("Register", "Dialog", Q_NULLPTR));
        label->setText(QApplication::translate("Register", "\350\264\246\345\217\267", Q_NULLPTR));
        label_2->setText(QApplication::translate("Register", "\345\257\206\347\240\201", Q_NULLPTR));
        label_3->setText(QApplication::translate("Register", "\347\241\256\350\256\244\345\257\206\347\240\201", Q_NULLPTR));
        label_4->setText(QApplication::translate("Register", "\345\207\272\347\224\237\346\227\245\346\234\237", Q_NULLPTR));
        label_5->setText(QApplication::translate("Register", "\347\224\265\350\257\235\345\217\267\347\240\201", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Register", "\347\241\256\350\256\244\346\263\250\345\206\214", Q_NULLPTR));
        ChoseHeadButton->setText(QApplication::translate("Register", "\351\200\211\346\213\251\345\244\264\345\203\217", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Register: public Ui_Register {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTER_H
