#include "register.h"
#include "ui_register.h"

QString nhead = "";
Register::Register(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Register)
{
    ui->setupUi(this);
}
Register::Register(QTcpSocket *sock,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Register)
{
    ui->setupUi(this);
    client=sock;
    connect(&CH,SIGNAL(SendData(QString)),this,SLOT(GetData(QString)));
}
Register::~Register()
{
    delete ui;
}

void Register::on_pushButton_clicked()
{
    QString uname=ui->lineEdit->text();
    if(ui->lineEdit_2->text().length()==0||ui->lineEdit_2->text()!=ui->lineEdit_3->text()){
        QMessageBox::warning(this,"注意","两次密码不一致或未输入密码");
        return;
    }
    QString pword=ui->lineEdit_2->text();
    QString pno=ui->lineEdit_4->text();
    QString pdate=ui->dateEdit->text();
    QString packdate="#|2|"+uname+"|"+pword+"|"+pno+"|"+pdate+"|"+nhead+"|&";
    qDebug()<<packdate;
    client->write(packdate.toUtf8());
}

void Register::on_ChoseHeadButton_clicked()
{
    CH.show();
}

void Register::GetData(QString str)
{
    nhead = str;
    ui->pushButton->setEnabled(true);
}
