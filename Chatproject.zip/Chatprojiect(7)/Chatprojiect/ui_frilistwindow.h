/********************************************************************************
** Form generated from reading UI file 'frilistwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRILISTWINDOW_H
#define UI_FRILISTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLayout>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FriListWindow
{
public:
    QToolBox *FriListBox;
    QWidget *myfri;
    QWidget *myfim;
    QWidget *blacklist;
    QWidget *widget;
    QLabel *label;
    QToolButton *userHead;
    QWidget *widget_2;
    QToolButton *addFriBtn;
    QToolButton *delFriBtn;

    void setupUi(QWidget *FriListWindow)
    {
        if (FriListWindow->objectName().isEmpty())
            FriListWindow->setObjectName(QStringLiteral("FriListWindow"));
        FriListWindow->resize(247, 483);
        FriListWindow->setStyleSheet(QStringLiteral("border-image: url(:/res/resource/background/backgroud5.jfif);"));
        FriListBox = new QToolBox(FriListWindow);
        FriListBox->setObjectName(QStringLiteral("FriListBox"));
        FriListBox->setGeometry(QRect(2, 52, 241, 391));
        QFont font;
        font.setBold(false);
        font.setWeight(50);
        FriListBox->setFont(font);
        FriListBox->setStyleSheet(QStringLiteral("background-color: rgb(237, 255, 234);"));
        myfri = new QWidget();
        myfri->setObjectName(QStringLiteral("myfri"));
        myfri->setGeometry(QRect(0, 0, 241, 313));
        FriListBox->addItem(myfri, QStringLiteral("Page 1"));
        myfim = new QWidget();
        myfim->setObjectName(QStringLiteral("myfim"));
        myfim->setGeometry(QRect(0, 0, 241, 313));
        FriListBox->addItem(myfim, QString::fromUtf8("\351\241\265"));
        blacklist = new QWidget();
        blacklist->setObjectName(QStringLiteral("blacklist"));
        blacklist->setGeometry(QRect(0, 0, 241, 313));
        FriListBox->addItem(blacklist, QString::fromUtf8("\351\241\265"));
        widget = new QWidget(FriListWindow);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, -30, 241, 81));
        label = new QLabel(widget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(93, 45, 121, 21));
        QFont font1;
        font1.setPointSize(13);
        font1.setBold(false);
        font1.setWeight(50);
        label->setFont(font1);
        userHead = new QToolButton(widget);
        userHead->setObjectName(QStringLiteral("userHead"));
        userHead->setGeometry(QRect(26, 38, 51, 41));
        widget_2 = new QWidget(FriListWindow);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(3, 450, 241, 31));
        addFriBtn = new QToolButton(widget_2);
        addFriBtn->setObjectName(QStringLiteral("addFriBtn"));
        addFriBtn->setGeometry(QRect(6, 0, 31, 31));
        QIcon icon;
        icon.addFile(QStringLiteral(":/res/resource/icon/user_add.png"), QSize(), QIcon::Normal, QIcon::Off);
        addFriBtn->setIcon(icon);
        addFriBtn->setIconSize(QSize(35, 25));
        delFriBtn = new QToolButton(widget_2);
        delFriBtn->setObjectName(QStringLiteral("delFriBtn"));
        delFriBtn->setGeometry(QRect(46, 0, 31, 31));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/res/resource/icon/user_delete.png"), QSize(), QIcon::Normal, QIcon::Off);
        delFriBtn->setIcon(icon1);
        delFriBtn->setIconSize(QSize(38, 25));

        retranslateUi(FriListWindow);

        FriListBox->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(FriListWindow);
    } // setupUi

    void retranslateUi(QWidget *FriListWindow)
    {
        FriListWindow->setWindowTitle(QApplication::translate("FriListWindow", "chat", Q_NULLPTR));
        FriListBox->setItemText(FriListBox->indexOf(myfri), QApplication::translate("FriListWindow", "Page 1", Q_NULLPTR));
        FriListBox->setItemText(FriListBox->indexOf(myfim), QApplication::translate("FriListWindow", "\351\241\265", Q_NULLPTR));
        FriListBox->setItemText(FriListBox->indexOf(blacklist), QApplication::translate("FriListWindow", "\351\241\265", Q_NULLPTR));
        label->setText(QApplication::translate("FriListWindow", "hahahaahah", Q_NULLPTR));
        userHead->setText(QApplication::translate("FriListWindow", "...", Q_NULLPTR));
        addFriBtn->setText(QApplication::translate("FriListWindow", "...", Q_NULLPTR));
        delFriBtn->setText(QApplication::translate("FriListWindow", "...", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class FriListWindow: public Ui_FriListWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRILISTWINDOW_H
